<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use DB;

class RegController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       return view('projectview.home');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {	
	
		
		$email_check = DB::table('registrations')
					->where('email', '=', $request->email)->first();
					if ($email_check === null) 
						{
							 $this->validate($request, [
							'firstname' => 'required|alpha|max:35',
							'lastname' => 'required|alpha|max:35',
							'dob'=>'required|date',
							'gender'=>'required',
							'country'=>'required',
							'state'=>'required',
							'city'=>'required',
							'email'=>'required|email',
							'pass'=>'required|confirmed',
							'pass_confirmation'=>'required'
							]);
									$password = Hash::make("$request->pass"); //hashing of password
									$id = DB::table('registrations')->insertGetId(
									['fname' => "$request->firstname",'lname' => "$request->lasttname",
									'dob' => "$request->dob",
									'gender' => "$request->gender",
									'country' => "$request->country",
									'state' => "$request->state",
									'city' => "$request->city",
									'created_at'=>  date("Y-m-d H:i:s"),
									'email'=>"$request->email",
									'pass'=>"$password"]
									);
							
							return view('/Sign_in');
							
						}
						else
						{
							echo "mail exists";
						}
		
		
		
		
		
		
		
		
		
		
		
		
				
		
      //  return $request->firstname."".$request->lastname."".$request->gender."".$request->dob."".$request->country."".$request->state."".$request->city."".date("Y-m-d");
    }

  
    public function show()
    {
          $registrations = DB::table('registrations')->get();

        return view('projectview.view', ['regidetail' => $registrations]);
    }

  
	Public function show_country()
	{
		$country = DB::table('desh')->get();
	
        return$country;
		//return view('projectview.home', ['count' => $country]);
	}
	public function getStateList(Request $request)
    {	
		$state = DB::table('states')
				->where('country_id', '=', $request->country_id)->get();
      
        return $state;//response()->json($states);
    }
	
	
	public function getCityList(Request $request)
    {	//return $request->state_id;
		$city = DB::table('city')
				->where('state_id', '=', $request->state_id)->get();
      
        return $city;
    }
}
