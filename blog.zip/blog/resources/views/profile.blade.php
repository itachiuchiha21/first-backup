<!DOCTYPE html>
<html>
<head>
<style>
header, footer {
    padding: 1em;
    color: white;
    background-color: black;
    clear: left;
    text-align: center;
}
div.absolute {
    position: absolute;
    top: 0px;
   right: 1;
    width: 247px;
    height: 25vh;
    border: 1px #0000;
}
div.absolutee {
    position: absolute;
    top: 25vh;
    right: 1;
    width: 250px;
    height: 25vh;
    border: 1px #73AD21;
}
</style>
</head>

<body>
<div style="width:100%;">
<header>
  <h1>City Gallery</h1>
</header>

<div style="width:20%;background-color:#6495ED;float:left;height:100vh;position:relative;">
left


<div class="absolute">
top
</div>


<div class="absolutee">
bottom
</div>


</div>



<div style="width:80%;background-color:#0000;float:right;height:50vh;">
right
</div>


</div>
</body>

</html>