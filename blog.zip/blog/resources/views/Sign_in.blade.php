<!DOCTYPE html>
<html>
<head>

</head>
<style>
.form_div{
	margin-left:auto;
	margin-right:auto;
}

input[type=email], select {
    width: 100%;
    padding: 5px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 8px;
    box-sizing: border-box;
}

input[type=password], select {
    width: 100%;
    padding: 5px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 8px;
    box-sizing: border-box;
}

input[type=submit] {
    width: 100%;
    background-color: #96191B;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
	
}

input[type=submit]:hover {
    background-color: #45a049;
}

div.detail {
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 20px;
	margin:auto;
}
div.background{
	background-color: #f2f2f2;
	
}
p.head
	  {
		   text-align: center;
		   border-radius: 5px;
		   background-color: #96191B;
		   padding: 20px;
		   font-size: 50px;
		   align:center;
		   text-shadow: 3px 2px grey;
		   color:white;
		
	  }
</style>
<body >
<div class="background" >

		<p class="head">Sign in </p>
			<div >
				
				<form action="/sign" method="GET">
				 {{ csrf_field() }}
				 @if (count($errors) > 0)
    <div style="color:red">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
				
				
						<table class="form_div">
							
									<td><label for="email">Email</label></td>
									<td><input type="email" id="email" name="email" placeholder="email"></td>
								</tr>
								
								
								<tr>
									<td><label for="pass">Password</label></td>
									<td><input type="password" id="pass" name="pass" placeholder="password"></td>
								</tr>
								
								
							
							
								
						
								<tr>
									<td>
										<input type="submit" value="Submit" >
									</td>
								</tr>
						</table>
						
				</form>
			</div>
</div>

</body>
</html>

