<!DOCTYPE html>
<html>
<head>

</head>
<style>
.form_div{
	margin-left:auto;
	margin-right:auto;
}
input[type=text], select {
    width: 100%;
    padding: 5px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 8px;
    box-sizing: border-box;
}

input[type=submit] {
    width: 100%;
    background-color: #96191B;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
	
}

input[type=submit]:hover {
    background-color: #45a049;
}

div.detail {
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 20px;
	margin:auto;
}
div.background{
	background-color: #f2f2f2;
	
}
p.head
	  {
		   text-align: center;
		   border-radius: 5px;
		   background-color: #96191B;
		   padding: 20px;
		   font-size: 50px;
		   align:center;
		   text-shadow: 3px 2px grey;
		   color:white;
		
	  }
</style>
<body >
<div class="background" action="/RegController@store" method="GET">

		<p class="head">Registration </p>
			<div >
				
				<form action="/action_page.php">
						<table class="form_div">
								<tr>
									<td><label for="fname">First Name</label></td>
									<td><input type="text" id="fname" name="firstname" placeholder="Your name.."></td>
								</tr>
							
								<tr>
									<td><label for="lname">Last Name</label></td>
									<td><input type="text" id="lname" name="lastname" placeholder="Your last name.."></td>
								</tr>
							
								<tr>
									<td><label for="gender">Gender</label></td>
									<td>
										<select id="gender" name="gender">
											<option value="male">Male</option>
											<option value="female">Female</option>
											<option value="other">Others</option>
										</select>
									</td>
								</tr>
							
								<tr>
									<td>
										<label for="dob" >Date of Birth</label></td>
										<td><input type="date" id="dob" name="dob">
									</td>
								</tr>
								
								<tr>
									<td><label for="country">Country</label></td>
									<td>
										<select id="country" name="country">
											<option selected="selected">
											
										</select>
									</td>
								</tr>
						
								<tr>
									<td><label for="state">State</label></td>
									<td>
										<select id="state" name="state" >
											<option selected="selected">
										</select>
									</td>
								</tr>
								
								<tr>
									<td><label for="city">City</label></td>
									<td>
										<select id="city" name="city" >
											<option selected="selected">
										</select>
									</td>
								</tr>

								
								
							
								
						
								<tr>
									<td>
										<input type="submit" value="Submit" >
									</td>
								</tr>
						</table>
						
				</form>
			</div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script>
$(document).ready(function()
{
 $.ajax({
           type:"GET",
           url:'/getre',
           success:function(res)
					{               
						if(res)
						{
								$("#country").empty();
								$("#country").append('<option>Select</option>');
								$.each(res,function(key,value)
										{
											//alert(value.id);
											$("#country").append('<option value="'+value.id+'">'+value.country+'</option>');
										})
						}
					
					}
            });
	
				
				
				
 });
 
 
 
 $('#country').on('change',function()
 {
	
	var country_value=$("#country option:selected").text();
	 //alert(country_value);
	
	var country_id=document.getElementById("country").value;
	//alert(country_id);
	 
	 if(country_value=="Select")				//casesensitive// .localeCompare(select); optional method
			{
				$('#state').empty();
				 $('#city').empty();
			}
	 else
			{
						
					$.ajax({
							
							type:"GET",
							url:'/getstate'+country_id,
							success:function(res)
											{               
												//alert('i am in state');
												if(res)
													{
													
													$("#state").empty();
													$("#state").append('<option>Select</option>');
													$.each(res,function(key,value)
															{
																
																$("#state").append('<option value="'+value.state_id+'">'+value.state_name+'</option>');
															})
													}
					
											}
						  });
	
			}
 });
 
 
//=========================================================================================================
 
 
 
 $('#state').on('change',function()
 {
	
	var state_value=$("#state option:selected").text();
	//alert(state_value);
	
	var state_id=document.getElementById("state").value;
	//alert(state_id);
 
		 if(state_value=="Select")				//casesensitive// .localeCompare(select); optional method
			{
				$('#city').empty();
			}
		else
			{
						
					$.ajax({
							
							type:"GET",
							url:'/getcity'+state_id,
							success:function(res)
											{               
												//alert('i am in city');
												if(res)
													{
													
													$("#city").empty();
													$("#city").append('<option>Select</option>');
													$.each(res,function(key,value)
															{
																
																$("#city").append('<option value="'+value.city_id+'">'+value.city_name+'</option>');
															})
													}
					
											}
						  });
			}
	 
});
 
 
 

</script>
</body>
</html>
